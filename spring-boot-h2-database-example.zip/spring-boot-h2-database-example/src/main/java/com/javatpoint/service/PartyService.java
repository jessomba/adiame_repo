package com.javatpoint.service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.model.Party;
import com.javatpoint.repository.PartyRepository;

@Service
public class PartyService {
	@Autowired
	PartyRepository partyRepository;

	public List<Party> getAllParty() {
		List<Party> parties = new ArrayList<Party>();
		partyRepository.findAll().forEach(party -> parties.add(party));
		return parties;
	}

	public Party getPartyById(String id) {
		return partyRepository.findById(id).get();
	}

	public void saveOrUpdate(Party party) {
		partyRepository.save(party);
	}

	public void delete(String id) {
		partyRepository.deleteById(id);
	}

	public void generatePartyFile(String[] data) {

		for (String s : data) {
			Party party = new Party();
			String uuid = UUID.randomUUID().toString().replace("-", "");
			party.setId(uuid);
			party.setData(s);
			party.setStatus("NOT_SENT");
			saveOrUpdate(party);
		}
		
		long start = System.currentTimeMillis();
        long end = start + 3 * 1000;
        
		if (System.currentTimeMillis() >= end) {
			List<Party> parties = getAllParty();
			try (BufferedWriter writer = new BufferedWriter(
					new FileWriter("C:\\jessomba\\data\\bp_couterparty_" + currentDate() + ".txt", true));) {

				int count = 0;
				writer.write("CLNTDTLS|" + currentDate() + "|MAESTRO");
				writer.newLine();
				int lines = 1;
				for (Party party : parties) {
					String oneLine = party.getData();
					count += Integer.parseInt(oneLine.split("\\|")[0]);
					writer.write(oneLine);
					writer.newLine();
					lines++;
					delete(party.getId());
				}
				writer.write("T|" + lines + "|" + count);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	private String currentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMuuuuHHmmss");
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);
	}

	public static void main(String[] args) {
		PartyService p = new PartyService();

		try {

			String[] data = { "0|599394880",

					"1|M|G|599394880|4|TULIPBAC|TULIP TREND FUND LTD - PB ACTIVITY|2||||01012018|2||67|KY||||||||KY|||||||||||||||50||||||",

					"2|M|G|599394880|||1|4||SOUTH CHURCH STREET||||12102018|||GEORGE TOWN|||KY|||",

					"3|M|599394880|8|4|G", "23|M|G|599394880|1|||4||||||||captone@sgcib.com||||||4" };

			p.generatePartyFile(data);

			TimeUnit.SECONDS.sleep(1);

			String[] data2 = { "0|599394880",

					"1|M|G|599394880|4|TULIPBAC|TULIP TREND FUND LTD - PB ACTIVITY|2||||01012018|2||67|KY||||||||KY|||||||||||||||50||||||",

					"2|M|G|599394880|||1|4||SOUTH CHURCH STREET||||12102018|||GEORGE TOWN|||KY|||",

					"3|M|599394880|8|4|G", "23|M|G|599394880|1|||4||||||||captone@sgcib.com||||||4" };

			p.generatePartyFile(data2);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}